﻿/*
 * Created by Ranorex
 * User: sstowe
 * Date: 6/1/2018
 * Time: 1:49 PM
 * 
 * To change this template use Tools > Options > Coding > Edit standard headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

using WinForms = System.Windows.Forms;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Repository;
using Ranorex.Core.Testing;

using Ranorex.Core.Data;
using System.Windows.Forms;

namespace BottomLineII
{
    /// <summary>
    /// InputHelpers contains reusable segments for entering information into the user interface.
    /// When sequences are repeated, there is no need for them to be recorded in each recording. 
    /// Mechanisms which are created to work around difficult user interface elements, they can be
    /// reused from here as well.
    /// </summary>
    [UserCodeCollection]
    public class InputHelpers
    {
   	
       
    	/// <summary>
        /// For test recordings to be portable and durable, it is helpful not to worry
        /// about whether the browser saves values for smart completion.
        /// This method clicks into the desired text box, performs a CTRL A click,
        /// performs a Delete key click then types the desired input value.
        /// </summary>
        [UserCodeMethod]
        public static void SetTextboxValue(RepoItemInfo inputtagInfo, string inputValue)
        {
			Report.Log(ReportLevel.Info, "SetInputValue", "Middle click on a repo item, add a space, delete a space", inputtagInfo);
			//inputtagInfo.FindAdapter<InputTag>().Click(System.Windows.Forms.MouseButtons.Left);
			//Keyboard.PrepareFocus(inputtagInfo.FindAdapter<InputTag>());
            //Keyboard.Press(System.Windows.Forms.Keys.Space | System.Windows.Forms.Keys.Control, Keyboard.DefaultScanCode, Keyboard.DefaultKeyPressTime, 1, true);
            inputtagInfo.FindAdapter<InputTag>().Click(System.Windows.Forms.MouseButtons.Middle);
			//Keyboard.PrepareFocus(inputtagInfo.FindAdapter<InputTag>());
            Keyboard.Press(System.Windows.Forms.Keys.End | System.Windows.Forms.Keys.Control, Keyboard.DefaultScanCode, Keyboard.DefaultKeyPressTime, 1, true);
            Keyboard.Press(System.Windows.Forms.Keys.End | System.Windows.Forms.Keys.Control, Keyboard.DefaultScanCode, Keyboard.DefaultKeyPressTime, 1, true);
            //Keyboard.Press(System.Windows.Forms.Keys.Space | System.Windows.Forms.Keys.Control, Keyboard.DefaultScanCode, Keyboard.DefaultKeyPressTime, 1, true);
            Keyboard.Press(System.Windows.Forms.Keys.Delete | System.Windows.Forms.Keys.Control, Keyboard.DefaultScanCode, Keyboard.DefaultKeyPressTime, 1, true);
        }
    }
}
